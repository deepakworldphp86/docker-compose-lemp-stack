<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

/**
 * Multiple wishlist item resource model
 *
 * @author      Magento Core Team <core@magentocommerce.com>
 */
namespace Magento\MultipleWishlist\Model\ResourceModel;

class Item extends \Magento\Wishlist\Model\ResourceModel\Item
{
}
