# Magento_BannerPageBuilder module

The Magento_BannerPageBuilder extends existing Dynamic Block tests in Magento EE, and adds new tests for PageBuilder usage.
