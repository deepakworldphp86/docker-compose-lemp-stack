# Scheduled Import Export Functional Tests

The Functional Test Module for **Magento Scheduled Import Export** module.
