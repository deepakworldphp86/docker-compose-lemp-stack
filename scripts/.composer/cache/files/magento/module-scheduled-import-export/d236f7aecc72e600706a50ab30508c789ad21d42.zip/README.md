Magento_ScheduledImportExport functionality allows to simplify routine of importing and/or exporting data in the store by automating this process.
Admin user can create a rule for importing or exporting new data (which could be Products, Customers and Customer Addresses) and specify date and time of the operation.
