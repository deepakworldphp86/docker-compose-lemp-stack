# Magento_GiftWrappingGraphQl

**Magento_GiftWrappingGraphQl** provides type and resolver information for the GraphQl module
to generate GiftWrapping information for order and cart.
