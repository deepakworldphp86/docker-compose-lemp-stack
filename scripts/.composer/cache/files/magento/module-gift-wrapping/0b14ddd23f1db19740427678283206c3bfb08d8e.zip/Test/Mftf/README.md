# Gift Wrapping Functional Tests

The Functional Test Module for **Magento Gift Wrapping** module.
