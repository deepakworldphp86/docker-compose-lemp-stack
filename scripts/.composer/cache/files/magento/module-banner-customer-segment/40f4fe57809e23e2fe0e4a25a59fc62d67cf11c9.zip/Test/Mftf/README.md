# Banner Customer Segment Functional Tests

The Functional Test Module for **Magento Banner Customer Segment** module.
