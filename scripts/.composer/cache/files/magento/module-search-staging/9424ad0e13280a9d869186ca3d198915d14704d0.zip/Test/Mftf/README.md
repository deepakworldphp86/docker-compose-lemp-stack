# Search Staging Functional Tests

The Functional Test Module for **Magento Search Staging** module.
