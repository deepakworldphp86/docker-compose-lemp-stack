# Gift Card Graph Ql Functional Tests

The Functional Test Module for **Magento Gift Card Graph Ql** module.
