# Tinymce3 Banner Functional Tests

The Functional Test Module for **Magento Tinymce3 Banner** module.
