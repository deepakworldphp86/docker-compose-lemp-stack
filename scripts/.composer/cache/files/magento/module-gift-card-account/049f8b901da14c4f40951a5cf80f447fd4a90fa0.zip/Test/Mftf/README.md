# Gift Card Account Functional Tests

The Functional Test Module for **Magento Gift Card Account** module.
