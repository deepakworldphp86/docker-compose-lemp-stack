<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\GiftCardAccount\Block\Adminhtml\Giftcardaccount\Form;

class Price extends \Magento\Catalog\Block\Adminhtml\Product\Helper\Form\Price
{
}
