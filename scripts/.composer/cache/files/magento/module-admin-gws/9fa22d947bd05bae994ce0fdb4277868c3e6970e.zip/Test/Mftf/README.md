# Admin Gws Functional Tests

The Functional Test Module for **Magento Admin Gws** module.
