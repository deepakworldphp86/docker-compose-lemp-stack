The Versions CMS Url Rewrite Module ties up the Store Switcher program with implementation of the Hierarchy structure. See also Magento_UrlRewrite and Magento_VersionsCms modules. 

Extends the Store Switcher program and makes it take into account nodes from the Hierarchy structure.
