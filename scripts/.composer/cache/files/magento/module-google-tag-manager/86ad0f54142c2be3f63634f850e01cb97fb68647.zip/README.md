Magento_GoogleTagManager is a module for integration with Google Tag Manager service.
