# Google Tag Manager Functional Tests

The Functional Test Module for **Magento Google Tag Manager** module.
