# Authorization Functional Tests

The Functional Test Module for **Magento Authorization** module.
