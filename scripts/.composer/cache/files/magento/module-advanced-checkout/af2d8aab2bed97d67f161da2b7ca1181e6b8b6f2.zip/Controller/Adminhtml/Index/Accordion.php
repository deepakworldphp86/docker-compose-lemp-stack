<?php
/**
 * Common action for accordion grids, ajax
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\AdvancedCheckout\Controller\Adminhtml\Index;

class Accordion extends Cart
{
}
