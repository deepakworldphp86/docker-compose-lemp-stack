# Gift Card Import Export Functional Tests

The Functional Test Module for **Magento Gift Card Import Export** module.
