<?php
/**
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Sales\Controller\Order;

use Magento\Sales\Controller\OrderInterface;

class Reorder extends \Magento\Sales\Controller\AbstractController\Reorder implements OrderInterface
{
}
