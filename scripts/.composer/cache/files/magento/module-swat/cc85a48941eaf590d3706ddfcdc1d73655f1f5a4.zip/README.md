Magento_Swat module provides access to the Site-Wide Analysis Tool
