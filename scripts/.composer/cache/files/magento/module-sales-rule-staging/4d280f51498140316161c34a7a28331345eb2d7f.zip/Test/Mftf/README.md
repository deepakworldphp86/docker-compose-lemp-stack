# Sales Rule Staging Functional Tests

The Functional Test Module for **Magento Sales Rule Staging** module.
