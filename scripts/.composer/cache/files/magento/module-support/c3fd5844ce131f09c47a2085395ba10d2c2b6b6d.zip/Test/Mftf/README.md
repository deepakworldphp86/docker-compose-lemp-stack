# Support Functional Tests

The Functional Test Module for **Magento Support** module.
