# Admin Gws Staging Functional Tests

The Functional Test Module for **Magento Admin Gws Staging** module.
