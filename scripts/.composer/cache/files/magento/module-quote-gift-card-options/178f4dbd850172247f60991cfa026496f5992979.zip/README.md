# QuoteGiftCardOptions

**QuoteGiftCardOptions** defines the data provider that creates buy requests for gift card products.
