# Review Functional Tests

The Functional Test Module for **Magento Review** module.
