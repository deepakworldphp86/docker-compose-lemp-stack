The Magento_CustomerCustomAttributes module handles user-defined customer and customer address attributes.
User-defined attributes are the ones, which are created by a store administrator additionally to the default ones.
