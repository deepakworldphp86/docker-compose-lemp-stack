# Customer Finance Functional Tests

The Functional Test Module for **Magento Customer Finance** module.
