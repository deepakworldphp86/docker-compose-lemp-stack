# CustomerBalanceGraphQl

The **CustomerBalanceGraphQl** provides type and resolver information for enabling customers to have a non-monetary balance in store credits associated to their accounts.
Store credit can be used by customers for shopping in the store and by the store administrator for making refunds.
