# Catalog Inventory Staging Functional Tests

The Functional Test Module for **Magento Catalog Inventory Staging** module.
