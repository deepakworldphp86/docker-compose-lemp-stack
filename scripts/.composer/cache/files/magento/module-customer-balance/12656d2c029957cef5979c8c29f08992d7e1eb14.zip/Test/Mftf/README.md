# Customer Balance Functional Tests

The Functional Test Module for **Magento Customer Balance** module.
