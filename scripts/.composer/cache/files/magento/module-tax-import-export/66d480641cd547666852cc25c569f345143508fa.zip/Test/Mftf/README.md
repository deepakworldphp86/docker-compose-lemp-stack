# Tax Import Export Functional Tests

The Functional Test Module for **Magento Tax Import Export** module.
