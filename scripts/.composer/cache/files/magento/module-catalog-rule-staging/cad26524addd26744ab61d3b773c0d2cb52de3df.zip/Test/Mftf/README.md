# Catalog Rule Staging Functional Tests

The Functional Test Module for **Magento Catalog Rule Staging** module.
