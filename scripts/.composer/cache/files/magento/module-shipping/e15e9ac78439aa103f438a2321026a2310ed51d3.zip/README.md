The Magento_Shipping module provides the abstract models and interfaces for a shipping carrier integration, including the web interface for the Shipment entity.
You need to extend these abstractions if you are adding new shipping carrier integration.
