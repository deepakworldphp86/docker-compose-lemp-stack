# Google Optimizer Staging Functional Tests

The Functional Test Module for **Magento Google Optimizer Staging** module.
