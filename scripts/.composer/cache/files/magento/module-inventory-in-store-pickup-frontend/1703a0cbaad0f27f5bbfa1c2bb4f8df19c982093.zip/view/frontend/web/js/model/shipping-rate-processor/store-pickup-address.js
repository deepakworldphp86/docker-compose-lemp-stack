/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

define([], function () {
    'use strict';

    return {
        /*eslint-disable no-unused-vars*/
        /**
         * @param {Object} address
         */
        getRates: function (address) {}
    };
});
