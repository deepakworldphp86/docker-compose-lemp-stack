# Gift Card Staging Functional Tests

The Functional Test Module for **Magento Gift Card Staging** module.
