# Resource Connections Functional Tests

The Functional Test Module for **Magento Resource Connections** module.
