# Promotion Permissions Functional Tests

The Functional Test Module for **Magento Promotion Permissions** module.
