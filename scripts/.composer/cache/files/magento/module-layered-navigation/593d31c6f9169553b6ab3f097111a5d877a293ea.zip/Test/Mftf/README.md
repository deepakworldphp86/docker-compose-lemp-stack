# Layered Navigation Functional Tests

The Functional Test Module for **Magento Layered Navigation** module.
