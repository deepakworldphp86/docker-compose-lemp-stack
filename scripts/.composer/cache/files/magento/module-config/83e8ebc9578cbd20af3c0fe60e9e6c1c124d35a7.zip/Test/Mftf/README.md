# Config Functional Tests

The Functional Test Module for **Magento Config** module.
