# Paypal Functional Tests

The Functional Test Module for **Magento Paypal** module.
