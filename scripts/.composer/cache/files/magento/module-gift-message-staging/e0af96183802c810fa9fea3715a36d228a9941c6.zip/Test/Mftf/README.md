# Gift Message Staging Functional Tests

The Functional Test Module for **Magento Gift Message Staging** module.
