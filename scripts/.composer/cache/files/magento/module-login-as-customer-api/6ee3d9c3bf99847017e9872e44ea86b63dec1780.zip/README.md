# Magento_LoginAsCustomer module

The Magento_LoginAsCustomerApi module provides API for ability to login into customer account for an admin user.
