# Widget Functional Tests

The Functional Test Module for **Magento Widget** module.
