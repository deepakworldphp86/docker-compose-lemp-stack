<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Eav\Model\Entity\Attribute\Frontend;

/**
 * @api
 * @since 100.0.2
 */
class DefaultFrontend extends \Magento\Eav\Model\Entity\Attribute\Frontend\AbstractFrontend
{
}
