# Gift Card Functional Tests

The Functional Test Module for **Magento Gift Card** module.
