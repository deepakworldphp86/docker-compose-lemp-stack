# Rma Graph Ql Functional Tests

The Functional Test Module for **Magento Rma Graph Ql** module.
