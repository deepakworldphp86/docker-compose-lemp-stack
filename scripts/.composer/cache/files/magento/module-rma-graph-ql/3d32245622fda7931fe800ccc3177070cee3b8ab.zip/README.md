# RmaGraphQl

**RmaGraphQl** provides type information for the GraphQl module
to generate rma fields for catalog and product information endpoints.
