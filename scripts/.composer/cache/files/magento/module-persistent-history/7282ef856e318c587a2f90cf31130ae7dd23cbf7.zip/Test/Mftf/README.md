# Persistent History Functional Tests

The Functional Test Module for **Magento Persistent History** module.
