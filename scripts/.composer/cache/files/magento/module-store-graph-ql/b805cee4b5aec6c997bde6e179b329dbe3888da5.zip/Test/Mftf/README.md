# Store Graph Ql Functional Tests

The Functional Test Module for **Magento Store Graph Ql** module.
