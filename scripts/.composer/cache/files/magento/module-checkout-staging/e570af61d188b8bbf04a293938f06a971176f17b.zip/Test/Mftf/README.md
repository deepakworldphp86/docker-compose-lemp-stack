# Checkout Staging Functional Tests

The Functional Test Module for **Magento Checkout Staging** module.
