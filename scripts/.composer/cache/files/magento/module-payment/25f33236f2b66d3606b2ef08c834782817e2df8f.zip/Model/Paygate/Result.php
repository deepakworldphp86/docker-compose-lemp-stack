<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Payment\Model\Paygate;

class Result extends \Magento\Framework\DataObject
{
}
