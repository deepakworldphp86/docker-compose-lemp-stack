The Banner module allows creating and managing dynamic blocks and widgets in Magento application. 
The Dynamic Block content can be specified by Store View.