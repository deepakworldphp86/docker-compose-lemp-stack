# Magento_MediaGalleryIntegration

The purpose of this module is to keep the integration of enhanced media gallery to Magento separated from implementation.
